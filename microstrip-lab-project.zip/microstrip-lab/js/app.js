const $ = (id) => document.getElementById(id);
const ids = ["er","h","w","t","freq","tanD"];
const defaults = {er:4.4,h:1.6,w:3,t:.035,freq:2.4,tanD:.02};
let frequencyChart, lossChart, matchChart;

function getInputs(){return Object.fromEntries(ids.map(id=>[id,Number($(id).value)]));}
function calculate(p){
  const er=p.er, h=p.h/1000, w=p.w/1000, f=p.freq*1e9;
  const u=w/h;
  // Quasi-static effective permittivity approximation.
  const eeff=(er+1)/2+(er-1)/2/Math.sqrt(1+12/u);
  let z0;
  if(u<=1) z0=60/Math.sqrt(eeff)*Math.log(8/u+u/4);
  else z0=120*Math.PI/(Math.sqrt(eeff)*(u+1.393+.667*Math.log(u+1.444)));
  const c=299792458, vp=c/Math.sqrt(eeff), lambda=vp/f;
  // First-order smooth-copper and dielectric attenuation estimates.
  const mu0=4*Math.PI*1e-7, sigma=5.8e7;
  const rs=Math.sqrt(Math.PI*f*mu0/sigma);
  const alphaC=rs/(z0*w)*1.15; // Np/m, empirical current-crowding factor
  const alphaD=(Math.PI*f/c)*Math.sqrt(eeff)*((er/(er-1))*((eeff-1)/eeff))*p.tanD/2;
  const npToDb=8.686;
  return {u,eeff,z0,vp,lambda,alphaC,alphaD,condDb:alphaC*npToDb,dielDb:alphaD*npToDb,totalDb:(alphaC+alphaD)*npToDb};
}
function fmt(n,d=2){return Number.isFinite(n)?n.toFixed(d):"—";}
function updateLabels(p){
  $("erOut").textContent=fmt(p.er,2);$("hOut").textContent=fmt(p.h,2)+" mm";
  $("wOut").textContent=fmt(p.w,2)+" mm";$("tOut").textContent=fmt(p.t,3)+" mm";
  $("freqOut").textContent=fmt(p.freq,2)+" GHz";$("tanDOut").textContent=fmt(p.tanD,4);
}
function updateGeometry(p,r){
  $("whRatio").textContent=fmt(r.u,3);$("materialName").textContent="εr = "+fmt(p.er,2);
  $("geometryFreq").textContent=fmt(p.freq,2)+" GHz";
  const width=Math.max(28,Math.min(230,70+p.w*18));
  $("stripRect").setAttribute("width",width);
  $("stripRect").setAttribute("x",(600-width)/2);
}
function updateElectrical(r){
  $("z0").textContent=fmt(r.z0,2);$("eeff").textContent=fmt(r.eeff,3);
  $("lambda").textContent=fmt(r.lambda*1000,2);$("velocity").textContent=fmt(r.vp/1e8,3);
  $("conductorLoss").textContent=fmt(r.condDb,3);
  $("dielectricLoss").textContent=fmt(r.dielDb,3);
  $("totalLoss").textContent=fmt(r.totalDb,3);
}
function chartDefaults(){
  Chart.defaults.color="#8da3b8";Chart.defaults.font.family="'DM Mono', monospace";
  Chart.defaults.font.size=10;Chart.defaults.borderColor="#20364d";
}
function makeCharts(p){
  if(!window.Chart){document.querySelectorAll(".chart-wrap").forEach(x=>x.innerHTML="<p class='notice'>Chart.js could not load. Check your internet connection and reload.</p>");return;}
  chartDefaults();
  const labels=Array.from({length:40},(_,i)=>(.5+i*(9.5/39)));
  const sweep=labels.map(f=>calculate({...p,freq:f}));
  const common={responsive:true,maintainAspectRatio:false,interaction:{mode:"index",intersect:false},plugins:{legend:{labels:{usePointStyle:true,boxWidth:7,padding:18}}},scales:{x:{title:{display:true,text:"Frequency (GHz)"},grid:{color:"#1c3044"}},y:{grid:{color:"#1c3044"}}}};
  if(frequencyChart)frequencyChart.destroy();
  frequencyChart=new Chart($("frequencyChart"),{type:"line",data:{labels:labels.map(x=>x.toFixed(2)),datasets:[{label:"Guided wavelength (mm)",data:sweep.map(x=>x.lambda*1000),borderColor:"#62c9ed",backgroundColor:"#62c9ed22",fill:true,tension:.25,pointRadius:0,yAxisID:"y"},{label:"Total attenuation (dB/m)",data:sweep.map(x=>x.totalDb),borderColor:"#e4b66b",tension:.25,pointRadius:0,yAxisID:"y1"}]},options:{...common,scales:{...common.scales,y:{...common.scales.y,title:{display:true,text:"Wavelength (mm)"}},y1:{position:"right",grid:{drawOnChartArea:false},title:{display:true,text:"Attenuation (dB/m)"}}}}});
  if(lossChart)lossChart.destroy();
  lossChart=new Chart($("lossChart"),{type:"line",data:{labels:labels.map(x=>x.toFixed(2)),datasets:[{label:"Conductor loss",data:sweep.map(x=>x.condDb),borderColor:"#62c9ed",tension:.25,pointRadius:0},{label:"Dielectric loss",data:sweep.map(x=>x.dielDb),borderColor:"#e4b66b",tension:.25,pointRadius:0}]},options:common});
}
function updateMatch(){
  const z=Number($("zref").value), r=Number($("rload").value), x=Number($("xload").value);
  if(!(z>0)||!Number.isFinite(r)||!Number.isFinite(x)){["gamma","returnLoss","vswr","reflectedPower","matchStatus"].forEach(id=>$(id).textContent="Enter valid values");return;}
  const den=(r+z)**2+x*x;
  const g=Math.sqrt(((r-z)**2+x*x)/den);
  const rl=g===0?"∞":(-20*Math.log10(g)).toFixed(2)+" dB";
  const vs=g>=1?"∞":((1+g)/(1-g)).toFixed(2);
  $("gamma").textContent=fmt(g,4);$("returnLoss").textContent=rl;
  $("vswr").textContent=vs;$("reflectedPower").textContent=fmt(g*g*100,2)+" %";
  $("matchStatus").textContent=g<.1?"Good match":g<.3?"Moderate mismatch":"High mismatch";
  if(matchChart){matchChart.data.datasets[0].data=[g,1-g];matchChart.update();}
}
function updateAll(){
  const p=getInputs(),r=calculate(p);updateLabels(p);updateGeometry(p,r);updateElectrical(r);makeCharts(p);
  $("zref").dataset.lineZ=r.z0.toFixed(2);updateMatch();
}
ids.forEach(id=>$(id).addEventListener("input",updateAll));
$("resetAll").addEventListener("click",()=>{ids.forEach(id=>$(id).value=defaults[id]);updateAll();});
$("useLineZ").addEventListener("click",()=>{$("zref").value=$("zref").dataset.lineZ;updateMatch();});
$("matchReset").addEventListener("click",()=>{$("zref").value=50;$("rload").value=75;$("xload").value=0;updateMatch();});
["zref","rload","xload"].forEach(id=>$(id).addEventListener("input",updateMatch));
if(window.Chart){
 chartDefaults();
 matchChart=new Chart($("matchChart"),{type:"bar",data:{labels:["Reflected","Accepted"],datasets:[{label:"Power fraction (%)",data:[0,100],backgroundColor:["#e4b66b","#62c9ed"],borderRadius:5}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{grid:{display:false}},y:{beginAtZero:true,max:100,title:{display:true,text:"Power (%)"},grid:{color:"#20364d"}}}}});
}
const navLinks=[...document.querySelectorAll(".nav-link")];
navLinks.forEach(a=>a.addEventListener("click",()=>{navLinks.forEach(x=>x.classList.remove("active"));a.classList.add("active");$("sidebar").classList.remove("open");$("currentSection").textContent=a.textContent.trim().toUpperCase();}));
$("menuToggle").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
updateAll();
