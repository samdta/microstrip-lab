# Microstrip Lab

## Run locally
1. Extract the ZIP.
2. Open the `microstrip-lab` folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the VS Code Live Server extension and click **Go Live**.
4. Chart.js is loaded from a CDN, so an internet connection is required for graphs.

## Files
- `index.html`: page structure and four modules
- `css/style.css`: responsive dark dashboard styling
- `js/app.js`: calculations, controls, and charts

## Model notes
This is an educational first-pass simulator. The impedance and effective-permittivity equations are quasi-static approximations. Loss calculations are simplified estimates and should not be treated as a fabrication sign-off. Validate engineering designs against a trusted transmission-line calculator, EM solver, and measurements.
